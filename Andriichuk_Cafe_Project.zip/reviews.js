// Reviews data for the carousel
window.reviews = [
  { name: 'Andrii', rating: 5, text: 'Bold coffee and cozy atmosphere. Perfect study spot!' },
  { name: 'Junior', rating: 4, text: 'Wholesome desserts. The Honey Cake is incredible.' },
  { name: 'Olena', rating: 5, text: 'Latte art is on point and the staff is super friendly.' },
  { name: 'Michael', rating: 5, text: 'Kyiv Cake took me back to my childhood. Amazing!' },
  { name: 'Sophie', rating: 4, text: 'Cappuccino is smooth, and the Lviv Cheesecake is a must-try.' }
];