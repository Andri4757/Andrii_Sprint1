// Reviews carousel with fade effect
let currentReview = 0;
function renderStars(n){ return '★'.repeat(n) + '☆'.repeat(5-n); }
function showReview() {
  const box = document.getElementById('review-carousel');
  if (!box || !window.reviews) return;
  box.classList.remove('fade-in');
  const r = reviews[currentReview];
  box.innerHTML = `<div style="font-size:1.1rem;line-height:1.6">"<span>${r.text}</span>"</div>
  <div style="margin-top:6px;color:#f2dfc2;font-weight:700">— ${r.name}</div>
  <div style="margin-top:4px;color:#d4a055" aria-label="Rating ${r.rating} of 5">${renderStars(Math.max(0, Math.min(5, r.rating||0)))}</div>`;
  void box.offsetWidth;
  box.classList.add('fade-in');
  currentReview = (currentReview + 1) % reviews.length;
}
setInterval(showReview, 3500);
document.addEventListener('DOMContentLoaded', showReview);

// Mobile nav toggle// 
document.addEventListener('click', (e) => {
  const toggle = e.target.closest('.nav-toggle');
  if (toggle) {
    const list = document.getElementById('nav-links');
    const open = list.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(open));
  }
});

// Add to Order (simple)
function addToOrder(item, price) {
  const key = 'orders';
  let orders = JSON.parse(localStorage.getItem(key)) || [];
  orders.push({ item, price });
  localStorage.setItem(key, JSON.stringify(orders));
  toast(`${item} added to your order`);
}

// Calculate Total
function calculateTotal() {
  let orders = JSON.parse(localStorage.getItem('orders')) || [];
  const total = orders.reduce((sum, o) => sum + Number(o.price || 0), 0);
  const el = document.getElementById('total-display');
  if (el) el.innerText = `Items: ${orders.length}  •  Total: $${total.toFixed(2)}`;
}

// Handle Order
function handleOrder(e) {
  e.preventDefault();
  alert('Thank you for your order!');
  localStorage.removeItem('orders');
  e.target.reset();
  const el = document.getElementById('total-display');
  if (el) el.textContent = '';
  return false;
}

// Tiny toast
function toast(msg){
  const t = document.createElement('div');
  t.textContent = msg;
  Object.assign(t.style, {
    position:'fixed',left:'50%',bottom:'24px',transform:'translateX(-50%)',
    background:'#000',color:'#fff',padding:'10px 14px',borderRadius:'10px',
    boxShadow:'0 8px 20px rgba(0,0,0,.4)',zIndex:9999,opacity:'0',
    transition:'opacity .2s ease'
  });
  document.body.appendChild(t);
  requestAnimationFrame(()=>{ t.style.opacity='1'; });
  setTimeout(()=>{
    t.style.opacity='0';
    setTimeout(()=>t.remove(), 200);
  }, 1400);
}
